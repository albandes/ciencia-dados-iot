from influxdb_client import InfluxDBClient, Point, WriteOptions, WritePrecision
from datetime import datetime
import random
import os

url = os.getenv("INFLUXDB_URL", "http://influxdb:8086")
token = os.getenv("INFLUXDB_TOKEN", "meu-token")
org = os.getenv("INFLUXDB_ORG", "minha-org")
bucket = os.getenv("INFLUXDB_BUCKET", "iot-dados")

client = InfluxDBClient(url=url, token=token, org=org)
write_api = client.write_api(write_options=WriteOptions(batch_size=1))

temperatura = round(random.uniform(22, 28), 2)
umidade = round(random.uniform(40, 60), 2)
timestamp = datetime.utcnow().isoformat()

ponto = (
    Point("medidas")
    .tag("sensor", "simulado")
    .field("temperatura", temperatura)
    .field("umidade", umidade)
    .time(timestamp, WritePrecision.NS)
)

write_api.write(bucket=bucket, org=org, record=ponto)
print(f"Dado inserido: {ponto}")

client.close()