# Notebook 2 – Armazenamento com InfluxDB via Docker

Este projeto insere dados simulados no InfluxDB 2.x usando um container Python com `influxdb-client`.

## 🔧 Pré-requisitos

- Docker e Docker Compose instalados

## ▶️ Como usar

1. Descompacte este diretório
2. Execute o comando:

```bash
docker-compose up --build
```

O serviço `armazenamento` irá simular um valor e gravar no InfluxDB.

## 🌐 Acesso ao InfluxDB

- Interface web: http://localhost:8086
- Org: `minha-org`
- Bucket: `iot-dados`
- Token: `meu-token`