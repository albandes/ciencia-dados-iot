import paho.mqtt.client as mqtt
from influxdb_client import InfluxDBClient, Point, WritePrecision
import json
import os

client_influx = InfluxDBClient(
    url=os.getenv("INFLUXDB_URL", "http://influxdb:8086"),
    token=os.getenv("INFLUXDB_TOKEN", "meu-token"),
    org=os.getenv("INFLUXDB_ORG", "minha-org")
)
write_api = client_influx.write_api()

def on_message(client, userdata, msg):
    dado = json.loads(msg.payload.decode())
    ponto = Point("medidas") \
        .tag("sensor", "simulado") \
        .field("temperatura", dado["temperatura"]) \
        .field("umidade", dado["umidade"]) \
        .time(dado["timestamp"], WritePrecision.NS)
    write_api.write(bucket=os.getenv("INFLUXDB_BUCKET", "iot-dados"), org=os.getenv("INFLUXDB_ORG", "minha-org"), record=ponto)

cliente_mqtt = mqtt.Client()
cliente_mqtt.on_message = on_message
cliente_mqtt.connect(os.getenv("MQTT_BROKER", "mosquitto"), 1883, 60)
cliente_mqtt.subscribe("iot/sensores")
cliente_mqtt.loop_forever()