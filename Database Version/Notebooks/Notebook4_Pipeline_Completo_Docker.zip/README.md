# Notebook 4 – Pipeline Completo: Sensor → MQTT → InfluxDB → Grafana

Este ambiente executa todos os componentes de um pipeline IoT via Docker Compose.

## Componentes

- Simulador de sensores (Python)
- Broker MQTT (Mosquitto)
- Subscriber MQTT → InfluxDB (Python)
- InfluxDB para armazenar os dados
- Grafana para visualização

## ▶️ Como usar

1. Descompacte o diretório
2. Execute:

```bash
docker-compose up --build
```

## 🌐 Acessos

- InfluxDB: http://localhost:8086
- Grafana: http://localhost:3000
- MQTT Broker (Mosquitto): localhost:1883

## 📂 Estrutura

- `/simulador`: envia dados MQTT
- `/subscriber`: insere dados no InfluxDB

**Autor:** Curso Ciência de Dados na IoT – 2025