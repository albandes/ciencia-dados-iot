import paho.mqtt.client as mqtt
import time
import random
import json
from datetime import datetime
import os

broker = os.getenv("MQTT_BROKER", "localhost")
port = 1883
topico = "iot/sensores"

cliente = mqtt.Client()
cliente.connect(broker, port, 60)

print("Enviando dados de sensores simulados...")
try:
    while True:
        dado = {
            "temperatura": round(random.uniform(22, 30), 2),
            "umidade": round(random.uniform(40, 60), 2),
            "timestamp": datetime.utcnow().isoformat()
        }
        payload = json.dumps(dado)
        cliente.publish(topico, payload)
        print("Publicado:", payload)
        time.sleep(5)
except KeyboardInterrupt:
    print("Interrompido pelo usuário.")
    cliente.disconnect()